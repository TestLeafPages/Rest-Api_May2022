package week3.day1.assignments;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateCRFile {
	
	@Test
	public void CreateCR() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/change_request";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		File file = new File("./src/test/resources/data.json");
		RequestSpecification request = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.queryParam("sysparm_fields", "number,sys_id")
				.body(file);
		Response response = request.post();
		System.out.println(response.statusLine());
		response.prettyPrint();
		
		
	}

}
