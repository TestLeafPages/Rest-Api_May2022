package week3.day1.assignments;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateCRNoBody {
	
	@Test
	public void CreateCR() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		RequestSpecification request = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.accept(ContentType.XML);
		Response response = request.post();
		System.out.println(response.statusCode());
		response.prettyPrint();
		
		
	}

}
