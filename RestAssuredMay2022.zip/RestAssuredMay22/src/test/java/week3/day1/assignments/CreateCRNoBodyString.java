package week3.day1.assignments;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateCRNoBodyString {
	
	@Test
	public void CreateCR() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		RequestSpecification request = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.accept(ContentType.XML)
				.queryParam("sysparm_fields", "number,sys_id")
				.body("{\r\n"
						+ "    \"short_description\":\"This is from the data file\",\r\n"
						+ "    \"description\":\"This is for description\",\r\n"
						+ "    \"category\":\"software\"\r\n"
						+ "\r\n"
						+ "}");
		Response response = request.post();
		System.out.println(response.getContentType());
		response.prettyPrint();
		
		
	}

}
