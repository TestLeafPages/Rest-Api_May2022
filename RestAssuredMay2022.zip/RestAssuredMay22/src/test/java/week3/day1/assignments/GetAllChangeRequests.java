package week3.day1.assignments;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllChangeRequests {
	
	@Test
	public void getChangeRequests() {
		
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/change_request";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		Response response = RestAssured.get();
		System.out.println(response.statusCode());
			
	}

}
