package week3.day1.assignments;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllChangeRequestsXML {
	
	@Test
	public void getChangeRequests() {
		
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/change_request";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		RequestSpecification request = RestAssured
									.given()
										.accept(ContentType.XML)
										.log()
										.all();
		Response response = request.get();
		response.prettyPrint();
		
	}

}
