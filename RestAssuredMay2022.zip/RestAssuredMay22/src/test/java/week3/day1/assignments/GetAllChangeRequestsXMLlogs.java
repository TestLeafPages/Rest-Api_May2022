package week3.day1.assignments;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllChangeRequestsXMLlogs {
	
	@Test
	public void getChangeRequests() {
		
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/change_request";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		Map<String,String> queryMap = new HashMap<String,String>();
		queryMap.put("sysparm_fields", "name,sys_id,category");
		queryMap.put("category", "software");
		RequestSpecification request = RestAssured
									.given()
										.accept(ContentType.JSON)
										.queryParams(queryMap)
										.log()
										.all();
		Response response = request.get();
							response
							.then()
							.log()
							.all();
							System.out.println(response.statusCode());
		
	}

}
