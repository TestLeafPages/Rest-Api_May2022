package week3.day1.basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentNoBody {
	
	@Test
	public void getIncidents() {
//		- Requirements
		
//		- End point
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		
				
//		- Add/construct Request - headers,queryparams,content-type,auth
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		RequestSpecification request = RestAssured.
										given()
										.contentType(ContentType.JSON);
		
//		- Send Request-Get,Post etc
		Response response = request.post();
		
		System.out.println(response.statusCode());
		
		response.prettyPrint();
//		- Validate the Response
	}

}
