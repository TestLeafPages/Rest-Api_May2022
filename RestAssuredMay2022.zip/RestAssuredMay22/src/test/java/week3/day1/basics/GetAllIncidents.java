package week3.day1.basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllIncidents {
	
	@Test
	public void getIncidents() {
//		- Requirements
		
//		- End point
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		
				
//		- Add/construct Request - headers,queryparams,content-type,auth
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
//		- Send Request-Get,Post etc
		Response response = RestAssured.get();
		
		System.out.println(response.statusCode());
		
		response.prettyPrint();
//		- Validate the Response
	}

}
