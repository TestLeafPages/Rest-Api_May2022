package week3.day1.basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentsWithQueryParam {
	
	@Test
	public void getIncidents() {
//		- Requirements
		
//		- End point
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
				
//		- Add/construct Request - headers,queryparams,content-type,auth
		
		RequestSpecification request = RestAssured.given().queryParam("sysparm_fields", "number,sys_id");
		
//		- Send Request-Get,Post etc
		
		
		Response response = request.get();
		
		System.out.println(response.statusCode());
		
		response.prettyPrint();
//		- Validate the Response
	}

}
