package week3.day2.assertions;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class LearnAssertions {
	//1. Verify the Status Code
	@Test
	private void statusCodeCheck() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
//		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		RestAssured.authentication = RestAssured.oauth2("UPBR-rGX-8WQrnN3_Bw5lz041q9r8uoZKl5XbREuj_iPmN9MdZCsW2Y09aPkWOZHwJpb3U1AzR9HZp8cvlIigA");
		Response response = RestAssured.get();
		response.then().assertThat().statusCode(206);
}
	//2. Verify the incident number is present in the response - INC0000009
	@Test
	private void incidentNumberCheck() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		Response response = RestAssured.get();
		response.then().assertThat().body("result.number", Matchers.hasItem("INC0000009"));
}
	//3. Verify the string "INC" is present in the response (number) using post
	@Test
	private void containsVerification() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		Response response = RestAssured
									.given().contentType(ContentType.JSON)
									.post();
		response.then().assertThat().body("result.number", Matchers.containsString("INC"));
}
	//4. Verify the incident number INC0000009 is equal to first result
	@Test
	private void equalString() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		Response response = RestAssured.get();
		response.then().assertThat().body("result[0].number", Matchers.equalTo("INC0000009"));

	}

}
