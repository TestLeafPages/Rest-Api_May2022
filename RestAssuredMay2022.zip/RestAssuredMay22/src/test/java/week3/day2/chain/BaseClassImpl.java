package week3.day2.chain;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseClassImpl {
	
	static RequestSpecification request=null;
	static String sys_id = null;
	
	@BeforeMethod
	public void setup() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		request = RestAssured.given().contentType(ContentType.JSON);

	}

}
