package week3.day2.chain;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class CreateIncident extends BaseClassImpl{
	
	@Test
	public void createIncidentTest() {
		Response response = request.post();
		sys_id = response.jsonPath().getString("result.sys_id");
		response.then().assertThat().statusCode(201);
	}

}
