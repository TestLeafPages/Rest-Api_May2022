package week3.day2.chain;

import org.testng.annotations.Test;

import io.restassured.response.Response;

public class DeleteIncident extends BaseClassImpl{
	
	@Test(dependsOnMethods = "week3.day2.chain.CreateIncident.createIncidentTest")
	public void deleteIncidentTest() {
		Response response = request.delete(sys_id);
		response.then().assertThat().statusCode(204);
	}

}
