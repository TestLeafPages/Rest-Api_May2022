package week3.day2.schema;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

public class SchemaValidation {
	
	@Test
	private void schemaTest() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		File file = new File("./src/test/resources/schema.json");
		Response response = RestAssured.get();
		response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(file));
		

	}

}
