package week3.day2.traversing;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DifferentWayOfWriting {
	
	@Test
	private void differentWays() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/change_request";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		
		
		//RequestSpecification request = RestAssured.given().contentType(ContentType.JSON);
		
		Response response2 = RestAssured.given().contentType(ContentType.JSON).get();
		
		response2.prettyPrint();
		
		
		Response response = RestAssured
								.given()
									.contentType(ContentType.JSON)
									.log()
									.all()
									.post();
									
		
		response.prettyPrint();
								

	}

}
