package week3.day2.traversing;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ManyItems {
	
	@Test
	private void manyItemsTest() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		
		Response response = RestAssured.given().contentType(ContentType.JSON).get();
		
		List<String> list = response.jsonPath().getList("result.sys_id");
		System.out.println("Incidents Count = > "+list.size());
		

	}

}
