package week3.day2.traversing;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class headrs {
	
	@Test
	private void manyItemsTest() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		//Method-1
//		Response response = RestAssured.given()
//								.contentType(ContentType.JSON)
//								.accept(ContentType.JSON)
//								.post();
//		
		
		List<Header> headersList = new ArrayList<Header>();
		headersList.add(new Header("Content-type","application/json"));
		headersList.add(new Header("accept","application/json"));
		Headers headerMap = new Headers();
		
		//Method-2
		//RestAssured.config = RestAssured.config().decoderConfig(decoderConfig().defaultContentCharset("UTF-8"));
		Response response = RestAssured
				.given()
				.log().all()
				
				.headers(headerMap)
				.post();
		
		response.then().assertThat().statusCode(201);
		

	}

}
