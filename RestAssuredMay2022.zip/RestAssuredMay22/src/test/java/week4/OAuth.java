package week4;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class OAuth {

	//public static String clientId = "c2411dbb29730110ca65ffbe6e6d1022";
//	public static String clientId = "accae8b311330110bc130419428748f1";
	public static String clientId = "78bf697b24b3011064f756607e1dfda4";
//	public static String clientSecret = "sample";
	public static String clientSecret = "admin";
//	public static String clientSecret = "drishith";
	public static String grant_type1 = "refresh_token";
	public static String grant_type2 = "password";
	public static String grant_type3 = "authorization_code";
	public static String refresh_token = null;
	public static String username = "abraham.lincoln";
	public static String password = "g>$rUiHP-bD;a&l^8^";
	public static String access_token = null;
	public static String redirect_uri = "https://oauth.pstmn.io/v1/callback";
	public static String code = "XMyQjyz-29oEX_IhR6cTxSFjlchc3VUSEExSP9iFhnb10pxf9cM8Ydm13xZJXgFaELHgo8j8_JxzKpDepdHgFw";
	
	
//	@BeforeSuite
//	public void getRefreshToken() {
//		RestAssured.baseURI = "https://dev106678.service-now.com/oauth_token.do";
//		//RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
//
//		
//        Response response = RestAssured.given()
//                
//                .contentType(ContentType.URLENC)
//                .formParam("grant_type", grant_type2)
//                .formParam("client_id", clientId)
//                .formParam("client_secret", clientSecret)
//                .formParam("username", username)
//                .formParam("password", password)
//                .post()
//                .then()
//                .statusCode(200)
//                .extract()
//                .response();
//        
//        refresh_token = response.jsonPath().get("refresh_token");
//        response.prettyPrint();
//	}
	
	@BeforeSuite
	public void getRefreshToken() {
		RestAssured.baseURI = "https://dev106678.service-now.com/oauth_token.do";
		//RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");

		
        Response response = RestAssured.given()
                
                .contentType(ContentType.URLENC)
                .formParam("grant_type", grant_type3)
                .formParam("client_id", clientId)
                .formParam("client_secret", clientSecret)
                .formParam("redirect_uri", redirect_uri)
                .formParam("code", code)
                .post();
//                .then()
//                .statusCode(200)
//                .extract()
//                .response();
        
        refresh_token = response.jsonPath().get("refresh_token");
        response.prettyPrint();
	}
	
	
	
	@BeforeMethod
	public void getAccessToken() {
        
				
				RestAssured.baseURI = "https://dev106678.service-now.com/oauth_token.do";
				//RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
        
				System.out.println("Refresh Token => "+refresh_token);
                Response response = RestAssured.given()
                        
                        .contentType(ContentType.URLENC)
                        .formParam("grant_type", grant_type1)
                        .formParam("client_id", clientId)
                        .formParam("client_secret", clientSecret)
                        .formParam("refresh_token", refresh_token)
                        
                        .post();
//                        .then()
//                        .statusCode(200)
//                        .extract()
//                        .response();
                
                access_token = response.jsonPath().get("access_token");
                response.prettyPrint();
    }
	
	@Test()
	public void createIncident() {
		System.out.println("Access Token => "+access_token);
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		Response post = RestAssured.given()
							.auth()
							.oauth2(access_token)
							.contentType(ContentType.JSON)
							.post();
		post.prettyPrint();
	}

}
