package week4.day1;

import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class StaticImportTest {
	
	@Test
	private void staticTest() {
		baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		authentication = basic("admin", "v*CJ@eHh3Ls1");
		Response response = get();
		response.then().assertThat().statusCode(200).body("result[0].number", containsString("INC"));
	}

}
