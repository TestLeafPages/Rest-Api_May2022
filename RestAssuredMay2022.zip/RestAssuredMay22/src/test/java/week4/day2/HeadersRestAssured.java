package week4.day2;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class HeadersRestAssured {
	
	@Test
	public void headers() {
		RestAssured.baseURI = "https://dev106678.service-now.com/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "v*CJ@eHh3Ls1");
		
		List<Header> headersList = new ArrayList<Header>();
		headersList.add(new Header("Content-type","application/json"));
		headersList.add(new Header("accept","application/json"));
		
		Headers headerMap = new Headers(headersList);
		
		Response response = RestAssured.given().log().all().headers(headerMap).get();
		response.prettyPrint();
		
	}

}
